#include <stdio.h>

int main()
{
    long long i,n,temp=0;
    scanf("%lld",&n);
    int arr[n];
    for(i=0;i<n;i++){
        scanf("%lld",&arr[i]);
    }
    temp=arr[n-1];
    arr[n-1]=arr[0];
    arr[0]=temp;
        
    for(i=0;i<n;i++){
         
        printf("%lld ",arr[i]);
        
        
    }
    
    return 0;
}
